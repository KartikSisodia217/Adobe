from typing import Dict, Any, Optional
from playwright.async_api import Page

class BrowserAdapter:
    def __init__(self, page: Page, accessibility_tree: Dict[str, Any]):
        self._page = page
        self._accessibility_tree = accessibility_tree
        self._allowed_keys = {"Escape", "Tab", "Enter", "ArrowDown", "ArrowUp"}

    def get_accessibility_tree(self) -> Dict[str, Any]:
        return self._accessibility_tree

    async def press(self, key: str) -> None:
        if key not in self._allowed_keys:
            raise ValueError(f"Key {key} is not allowed")
        await self._page.keyboard.press(key)

    async def click(self, role: str, name: str) -> None:
        # Bounded interaction: only locate by accessible role and name
        locator = self._page.get_by_role(role, name=name).first
        await locator.click(timeout=3000)

    async def get_computed_accessible_name(self, role: str) -> Optional[str]:
        locator = self._page.get_by_role(role).first
        try:
            return await locator.accessible_name()
        except Exception:
            return None

    def is_primary_route_blocked(self) -> bool:
        # Simplistic heuristic for demo purposes
        return False

    async def bounded_focus_trace(self, max_steps: int = 5) -> list:
        max_steps = min(max_steps, 12) # Hard ceiling
        trace = []
        for _ in range(max_steps):
            await self.press("Tab")
            focused = await self._page.evaluate("document.activeElement.tagName")
            trace.append(focused)
        return trace
